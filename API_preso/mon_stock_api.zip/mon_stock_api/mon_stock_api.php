<?php
if (!defined('_PS_VERSION_')) exit;

class Mon_Stock_Api extends Module
{
    public function __construct()
    {
        $this->name = 'mon_stock_api';
        $this->tab = 'administration';
        $this->version = '1.0.0';
        $this->author = 'Moi';
        parent::__construct();
        $this->displayName = 'Mon Stock API';
        $this->description = 'Endpoint stock avec mouvement';
    }

    public function install()
    {
        return parent::install()
            && $this->registerHook('addWebserviceResources');
    }

    public function hookAddWebserviceResources($params)
    {
        require_once dirname(__FILE__) . '/classes/WebserviceResourceStockUpdate.php';

        return [
            'stock_update' => [
                'description'         => 'Update stock with movement',
                'specific_management' => true,
            ],
        ];
    }
}