<?php
class StockUpdateWebserviceResource extends ObjectModel
{
    public $id_product;
    public $id_product_attribute;
    public $delta;

    public static $definition = [
        'table' => 'stock_update',
        'primary' => 'id_stock_update',
        'fields' => [
            'id_product' => [
                'type' => self::TYPE_INT,
                'validate' => 'isUnsignedId',
                'required' => true,
            ],
            'id_product_attribute' => [
                'type' => self::TYPE_INT,
                'validate' => 'isUnsignedId',
                'required' => false,
            ],
            'delta' => [
                'type' => self::TYPE_INT,
                'validate' => 'isInt',
                'required' => true,
            ],
        ],
    ];

    protected $webserviceParameters = [
        'objectNodeName' => 'stock_update',
        'objectsNodeName' => 'stock_updates',
        'fields' => [
            'id_product' => [],
            'id_product_attribute' => [],
            'delta' => [],
        ],
        'associations' => [],
    ];
}

class WebserviceSpecificManagementStockUpdate implements WebserviceSpecificManagementInterface
{
    protected $output = '';
    protected $ws_object;
    protected $objOutput;

    public function setObjectsArray(&$objs) {}
    public function getObjectsArray() { return []; }
    public function setWsObject(WebserviceRequest $obj) { $this->ws_object = $obj; return $this; }
    public function getWsObject() { return $this->ws_object; }
    public function getContent() { return $this->output; }
    public function setObjectOutput(WebserviceOutputBuilder $object) { $this->objOutput = $object; return $this; }
    public function getObjectOutput() { return $this->objOutput; }

    public function manage()
    {
        if ($_SERVER['REQUEST_METHOD'] === 'GET' || $_SERVER['REQUEST_METHOD'] === 'HEAD') {
            return $this->manageGetAndHead();
        }

        if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
            return $this->manageDelete();
        }

        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            throw new WebserviceException('POST ou DELETE seulement', [405, 405]);
        }

        $body = $this->getRequestBody();

        $idProduct          = (int) ($body['id_product'] ?? 0);
        $idProductAttribute = (int) ($body['id_product_attribute'] ?? 0);
        $delta              = (int) ($body['delta'] ?? 0);

        if (!$idProduct || !$delta) {
            throw new WebserviceException('id_product et delta obligatoires', [400, 400]);
        }

        $idStock = (int) Db::getInstance()->getValue(
            'SELECT id_stock_available FROM ' . _DB_PREFIX_ . 'stock_available
             WHERE id_product = ' . $idProduct . '
             AND id_product_attribute = ' . $idProductAttribute
        );

        if (!$idStock) {
            throw new WebserviceException('Stock introuvable pour ce produit', [404, 404]);
        }

        Db::getInstance()->insert('stock_mvt', [
            'id_stock'            => $idStock,
            'id_order'            => null,
            'id_supply_order'     => null,
            'id_stock_mvt_reason' => 1,
            'id_employee'         => 0,
            'employee_firstname'  => 'API',
            'employee_lastname'   => 'externe',
            'physical_quantity'   => abs($delta),
            'date_add'            => date('Y-m-d H:i:s'),
            'sign'                => $delta > 0 ? 1 : -1,
            'price_te'            => 0,
            'last_wa'             => 0,
            'current_wa'          => 0,
            'referer'             => 0,
        ]);

        StockAvailable::updateQuantity($idProduct, $idProductAttribute, $delta);

        $resource = $this->buildResourceObject();
        $resource->id = $idStock;
        $resource->id_product = $idProduct;
        $resource->id_product_attribute = $idProductAttribute;
        $resource->delta = $delta;

        $this->output = $this->objOutput->getContent(
            ['empty' => $this->buildResourceObject(), $resource],
            null,
            'full',
            $this->ws_object->depth,
            WebserviceOutputBuilder::VIEW_DETAILS
        );

        return true;
    }

    protected function manageGetAndHead()
    {
        $resource = $this->buildResourceObject();
        $this->ws_object->resourceConfiguration = $resource->getWebserviceParameters();

        if (isset($this->ws_object->urlFragments['schema'])) {
            $schema = $this->ws_object->urlFragments['schema'];
            if (!in_array($schema, ['blank', 'synopsis'])) {
                throw new WebserviceException('schema doit etre blank ou synopsis', [400, 400]);
            }

            $this->output = $this->objOutput->getContent(
                ['empty' => $resource],
                $schema,
                'full',
                $this->ws_object->depth,
                WebserviceOutputBuilder::VIEW_DETAILS
            );

            return true;
        }

        if (!$this->ws_object->setFieldsToDisplay()) {
            return false;
        }

        $resource->id = 1;
        $resource->id_product = 0;
        $resource->id_product_attribute = 0;
        $resource->delta = 0;

        $this->output = $this->objOutput->getContent(
            ['empty' => $this->buildResourceObject(), $resource],
            null,
            $this->ws_object->fieldsToDisplay,
            $this->ws_object->depth,
            WebserviceOutputBuilder::VIEW_LIST
        );

        return true;
    }

    protected function manageDelete()
    {
        $id = null;
        if (isset($this->ws_object->urlSegment[1]) && $this->ws_object->urlSegment[1] !== '') {
            $id = (int)$this->ws_object->urlSegment[1];
        }

        if (!$id) {
            throw new WebserviceException('ID requis pour la suppression', [400, 400]);
        }

        $deleted = Db::getInstance()->delete('stock_mvt', 'id_stock_mvt = ' . $id);

        if (!$deleted) {
            throw new WebserviceException('Mouvement introuvable ou erreur suppression', [404, 404]);
        }

        $resource = $this->buildResourceObject();
        $this->output = $this->objOutput->getContent(
            ['empty' => $resource],
            null,
            $this->ws_object->fieldsToDisplay,
            $this->ws_object->depth,
            WebserviceOutputBuilder::VIEW_LIST
        );

        return true;
    }

    protected function buildResourceObject()
    {
        return new StockUpdateWebserviceResource();
    }

    protected function getRequestBody()
    {
        $rawBody = file_get_contents('php://input');
        $jsonBody = json_decode($rawBody, true);

        if (is_array($jsonBody)) {
            return $jsonBody;
        }

        if (trim($rawBody) === '') {
            return [];
        }

        $xml = @simplexml_load_string($rawBody);
        if ($xml === false) {
            return [];
        }

        if (isset($xml->stock_update)) {
            $xml = $xml->stock_update;
        }

        return [
            'id_product' => (string) $xml->id_product,
            'id_product_attribute' => (string) $xml->id_product_attribute,
            'delta' => (string) $xml->delta,
        ];
    }
}
