<?php
class Mon_Stock_ApiFrontUpdateModuleFrontController extends ModuleFrontController
{
    public function initContent()
    {
        $secret = Tools::getValue('secret');
        if ($secret !== '5U4CKYHZWDWB8865EKTC1GLMCE4G4EKM') {
            die(json_encode(['error' => 'Unauthorized']));
        }

        $idProduct          = (int) Tools::getValue('id_product');
        $idProductAttribute = (int) Tools::getValue('id_product_attribute', 0);
        $delta              = (int) Tools::getValue('delta');

        if (!$idProduct || !$delta) {
            die(json_encode(['error' => 'Paramètres manquants']));
        }

        StockAvailable::updateQuantity($idProduct, $idProductAttribute, $delta);

        $newQty = StockAvailable::getQuantityAvailableByProduct($idProduct, $idProductAttribute);

        die(json_encode([
            'success'      => true,
            'id_product'   => $idProduct,
            'delta'        => $delta,
            'new_quantity' => $newQty
        ]));
    }
}